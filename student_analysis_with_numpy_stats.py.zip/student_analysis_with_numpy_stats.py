
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load data
df = pd.read_csv('student_data.csv')

# Display data
print("Student Data:")
print(df)

# NumPy statistics
math_scores = df['Math'].values
science_scores = df['Science'].values
english_scores = df['English'].values

math_mean = np.mean(math_scores)
science_std = np.std(science_scores)
english_median = np.median(english_scores)

print(f"\nMean Math Score: {math_mean}")
print(f"Standard Deviation of Science Scores: {science_std}")
print(f"Median English Score: {english_median}")

# Plot average scores
plt.figure(figsize=(10, 6))
plt.bar(df['Name'], df['Average'], color=['green' if x >= 80 else 'red' for x in df['Average']])
plt.xlabel('Students')
plt.ylabel('Average Score')
plt.title('Student Average Scores and Results')
plt.show()
